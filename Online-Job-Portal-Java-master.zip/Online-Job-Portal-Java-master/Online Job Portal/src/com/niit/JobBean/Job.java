package com.niit.JobBean;

public class Job {

	private String Location;
	private String Farea;
	private String jpost;
	private int Vacancy;
	private String salary;
	private String Idate;
	private String Itime;
	private String Iplace;
	private String skills;
	private String company;
	
	public String getLocation() {
		return Location;
	}
	public void setLocation(String location) {
		Location = location;
	}
	public String getFarea() {
		return Farea;
	}
	public void setFarea(String farea) {
		Farea = farea;
	}
	
	
	
	public String getJpost() {
		return jpost;
	}
	public void setJpost(String jpost) {
		this.jpost = jpost;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public int getVacancy() {
		return Vacancy;
	}
	public void setVacancy(int vacancy) {
		Vacancy = vacancy;
	}
	public String getSalary() {
		return salary;
	}
	public void setSalary(String salary) {
		this.salary = salary;
	}
	public String getIdate() {
		return Idate;
	}
	public void setIdate(String idate) {
		Idate = idate;
	}
	public String getItime() {
		return Itime;
	}
	public void setItime(String itime) {
		Itime = itime;
	}
	public String getIplace() {
		return Iplace;
	}
	public void setIplace(String iplace) {
		Iplace = iplace;
	}
	public String getSkills() {
		return skills;
	}
	public void setSkills(String skills) {
		this.skills = skills;
	}
	
	
}
